package org.kafka;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.*;
import org.apache.kafka.streams.state.KeyValueStore;
import org.kafka.timestamp.Extractor;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;

public class Streams {

    public static void main(final String[] args) throws Exception {
        Properties props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "streams-poc-application");
        props.put("bootstrap.servers", "kserver");
        props.put("sasl.jaas.config", "apikey");
        props.put("security.protocol", "SASL_SSL");
        props.put("sasl.mechanism", "PLAIN");
        props.put(StreamsConfig.DEFAULT_TIMESTAMP_EXTRACTOR_CLASS_CONFIG, Extractor.class);
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());


        StreamsBuilder builder = new StreamsBuilder();
        KStream<String, String> stream = builder.stream("streams_poc");

        Duration windowSize = Duration.ofMinutes(5);
        Duration gracePeriod = Duration.ofMinutes(1);
        KStream<Windowed<String>, String> grouped = stream.groupByKey()
                            .windowedBy(TimeWindows.ofSizeWithNoGrace(windowSize))
                            .reduce((s, v1) -> {
                                System.out.println(v1);
                                return v1;})
                            .toStream().peek((stringWindowed, s) -> {
                    System.out.println(stringWindowed.key());
                    System.out.println(stringWindowed.window().endTime().getEpochSecond());
                    System.out.println(s);
                });

        /*KTable<String, Long> wordCounts = textLines
                .flatMapValues(textLine -> Arrays.asList(textLine.toLowerCase().split("\\W+")))
                .groupBy((key, word) -> word)
                .count(Materialized.<String, Long, KeyValueStore<Bytes, byte[]>>as("counts-store"));
        wordCounts.toStream().to("streams_words_count", Produced.with(Serdes.String(), Serdes.Long()));*/
        KafkaStreams streams = new KafkaStreams(builder.build(), props);
        streams.start();
        Thread.sleep(15000);
        Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
    }


}
